const btnEl= document.querySelector(".btn");
  btnEl.addEventListener("click", ()=>{
    createPassword();
  });
iconEl.addEventListener("click",() =>{
  copyPassword();
});
  const iconEl=document.querySelector(".icon");
const activeEl=document.queruSelector(".active");

  function createPassword(){
    const chars = "qwertyuiopasdfghjklzxcvbnASDFGJHKLMNBVCXZQWERTYUIOP1234567890#()_?!+=$&@/*£€¥¢¤©®%|×÷÷¡µ^}{";
  const  passwordLength = 10;
    let password = "";
    for( let index= 0; index < passwordLength; index++){
      const randomNum=Math.floor(Math.random() * chars.length);
      password += chars.substring(randomNum, randomNum + 1);
      
    }
   const inputEl= document.getElementById("input");
 inputEl.value = password;
    activeEl.innerText= password + "copied!";
  }
function copyPassword(){
  inputEl.select();
  inputEl.setSelectionRange(0,9999 );
  navigator.clipboard.writeText(inputEl.value)
}
