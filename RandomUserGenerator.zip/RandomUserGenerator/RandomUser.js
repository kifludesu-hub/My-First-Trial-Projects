let btn=  document.querySelector(".btn");
 let msg= document.createElement("p");
 btn.addEventListener("click", async  ()=>{
  try{  let response= await fetch("https://randomuser.me/api/");
let  data=await response.json();
let user= data.results[0];
				document.getElementById("name").textContent = user.name.first;
  document.getElementById("email").textContent = user.email;
  document.getElementById("photo").src = user.picture.large;}
 				catch{
 								msg.textContent = "Failed to fetch! Please try again later!";
 								msg.style.color= "red";
 								document.body.appendChild(msg);
 						setTimeout(()=>{msg.textContent="";},1000)		;
 				}
});
  

