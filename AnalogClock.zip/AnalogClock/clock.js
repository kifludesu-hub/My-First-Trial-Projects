document.addEventListener('DOMContentLoaded', () => {
    const hourHand = document.querySelector('.needles .h');
    const minuteHand = document.querySelector('.needles .m');
    const secondHand = document.querySelector('.needles .s');
    
    function updateClock() {
        const now = new Date();
        const seconds = now.getSeconds();
        const minutes = now.getMinutes();
        const hours = now.getHours();
        
        // Calculate degrees (no +90 offset needed if CSS positions at 12 o'clock)
        const secondsDeg = seconds * 6;// (seconds/60)*360deg
        const minutesDeg = (minutes * 6)/*(minutes/60)*360deg*/+ (seconds * 0.1);
        const hoursDeg = ((hours % 12) * 30) /*(hrs/12)*360*/+ (minutes * 0.5);
        
        // Apply transforms - matching your CSS positioning
        if (secondHand) {
            secondHand.style.transform = `translate(-50%, -80%) rotate(${secondsDeg}deg)`;
        }
        if (minuteHand) {
            minuteHand.style.transform = `translate(-50%,-100%) rotate(${minutesDeg}deg)`;
        }
        if (hourHand) {
            hourHand.style.transform = `translate(-50%,-100%) rotate(${hoursDeg}deg)`;
        }
    }
    
    updateClock();
    setInterval(updateClock, 1000);
   // console.log(updateClock());
});
