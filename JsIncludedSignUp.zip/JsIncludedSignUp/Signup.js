
let btn = document.getElementById("id01");
let msg = document.querySelector(".msg");

btn.addEventListener("click", () => {
   let name = document.getElementById("uname").value;
  let email = document.getElementById("email").value;
  let psd = document.getElementById("psd").value;
  let psdc = document.getElementById("psdc").value;

  if (name === "") {
    msg.textContent = "Username is required!";
    msg.style.color = "red";
    setTimeout(()=>
    {
      msg.textContent = "";
      
    },1000);
    
  } else if (email === "") {
    msg.textContent = "Email is required!";
    msg.style.color = "red";
    setTimeout(()=>
    {
      msg.textContent = "";
      
    },1000);
  } else if (psd.length < 8) {
    msg.textContent = "Password must be at least 8 characters!";
    msg.style.color = "red";
    setTimeout(()=>
    {
      msg.textContent = "";
    },1000);
  } else if (psdc !== psd) {
    msg.textContent = "Passwords don't match!";
    msg.style.color = "red";
    setTimeout(()=>
    {
      msg.textContent = "";
    },1000);
  } else {
    msg.textContent = "Sign up successful!";
    msg.style.color = "green";
    
    /*name.value="";
    email.value="";
    password.value="";
    */
    setTimeout(()=>
    {
      msg.textContent = "";
    },1000);
    
  }
  
});
